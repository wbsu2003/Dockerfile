var appTarget = document.getElementById('app');
new linkding.Popup({target: appTarget});