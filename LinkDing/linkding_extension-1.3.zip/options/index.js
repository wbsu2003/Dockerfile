var appTarget = document.getElementById('app');
new linkding.Options({target: appTarget});